"use strict";

let allEvents = [];
let currentPage = 1;
let itemsPerPage = 25; // Default value

// Function to fetch and parse XML
function fetchEvents() {
  return fetch('events.rss')
    .then(response => response.text())
    .then(text => {
      const parser = new DOMParser();
      const xmlDoc = parser.parseFromString(text, "text/xml");
      return Array.from(xmlDoc.getElementsByTagName("item"));
    })
    .catch(error => {
      console.error("Error fetching events:", error);
      return [];
    });
}

// Function to parse dates in a consistent format
function parseDate(dateString) {
  const date = new Date(dateString);
  if (!isNaN(date.getTime())) {
    return date;
  }
  console.error(`Unable to parse date: ${dateString}`);
  return null;
}

// Function to extract the primary date from an event item (use the <start> date if available)
function extractPrimaryDate(item) {
  const startDateElement = item.querySelector("start");
  if (startDateElement) {
    return parseDate(startDateElement.textContent);
  }

  const pubDate = item.querySelector("pubDate") ? parseDate(item.querySelector("pubDate").textContent) : null;
  if (pubDate) {
    return pubDate;
  }

  const descriptionTimeElement = item.querySelector("time");
  if (descriptionTimeElement) {
    return parseDate(descriptionTimeElement.getAttribute("datetime"));
  }

  return null;
}

// Function to create event card using template literals
function createEventCard(item) {
  const title = item.querySelector("title").textContent;
  const description = item.querySelector("description").textContent;
  const eventDate = extractPrimaryDate(item);
  const location = item.querySelector("location") ? item.querySelector("location").textContent : "No location specified";
  const imageUrl = item.querySelector("enclosure") ? item.querySelector("enclosure").getAttribute("url") : "placeholder-image.jpg";

  const formattedDate = eventDate ? new Date(eventDate).toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  }) : "Date not available";

  const card = document.createElement("article");
  card.className = "event-card";
  card.innerHTML = `
    <img src="${imageUrl}" alt="${title}" onerror="this.src='img/img.png';">
    <div class="event-card-content">
        <h2>${title}</h2>
        <p class="event-date">${formattedDate}</p>
        <p class="event-location">${location}</p>
        <button class="learn-more">Learn More</button>
        <div class="event-description" style="display: none;">${description}</div>
    </div>
  `;

  card.querySelector(".learn-more").addEventListener("click", (e) => {
    const descriptionElement = card.querySelector(".event-description");
    if (descriptionElement.style.display === "none") {
      descriptionElement.style.display = "block";
      e.target.textContent = "Show Less";
    } else {
      descriptionElement.style.display = "none";
      e.target.textContent = "Learn More";
    }
  });

  return card;
}

// Function to display events with pagination
function displayEvents(events) {
  const container = document.getElementById("eventsContainer");
  container.innerHTML = "";

  let startIndex = (currentPage - 1) * itemsPerPage;
  let endIndex = itemsPerPage === 'all' ? events.length : Math.min(startIndex + itemsPerPage, events.length);

  // If "Show all" is selected, set startIndex and endIndex accordingly
  if (itemsPerPage === 'all') {
    startIndex = 0;
    endIndex = events.length;
  }

  for (let i = startIndex; i < endIndex; i++) {
    container.appendChild(createEventCard(events[i]));
  }

  updatePaginationControls(events.length);
  document.getElementById("filterCount").textContent = `Showing ${endIndex - startIndex} of ${events.length} events`;
}

// Function to update pagination controls
function updatePaginationControls(totalItems) {
  const totalPages = itemsPerPage === 'all' ? 1 : Math.ceil(totalItems / itemsPerPage);
  const pageInfo = `Page ${currentPage} of ${totalPages}`;

  document.getElementById("pageInfo").textContent = pageInfo;
  document.getElementById("pageInfoBottom").textContent = pageInfo;

  document.getElementById("prevPage").disabled = currentPage === 1 || itemsPerPage === 'all';
  document.getElementById("prevPageBottom").disabled = currentPage === 1 || itemsPerPage === 'all';
  document.getElementById("nextPage").disabled = currentPage === totalPages || itemsPerPage === 'all';
  document.getElementById("nextPageBottom").disabled = currentPage === totalPages || itemsPerPage === 'all';
}

// Filter functions
function filterEvents(events, filterValue, filterFunction) {
  return events.filter(event => filterFunction(event, filterValue));
}

function titleFilter(event, filterValue) {
  return event.querySelector("title").textContent.toLowerCase().includes(filterValue.toLowerCase());
}

function startDateFilter(event, filterValue) {
  const eventDate = extractPrimaryDate(event);
  if (!eventDate) return false;

  const filterDate = new Date(filterValue);
  const normalizedFilterDate = filterDate.toISOString().split('T')[0];
  const normalizedEventDate = eventDate.toISOString().split('T')[0];

  return normalizedEventDate === normalizedFilterDate;
}

function descriptionFilter(event, filterValue) {
  return event.querySelector("description").textContent.toLowerCase().includes(filterValue.toLowerCase());
}

// Event listeners
document.addEventListener("DOMContentLoaded", () => {
  fetchEvents()
    .then(events => {
      allEvents = events;
      displayEvents(events);

      document.getElementById("applyFilters").addEventListener("click", applyFilters);
      document.getElementById("clearFilters").addEventListener("click", clearFilters);
      document.getElementById("prevPage").addEventListener("click", () => changePage(-1));
      document.getElementById("nextPage").addEventListener("click", () => changePage(1));
      document.getElementById("prevPageBottom").addEventListener("click", () => changePage(-1));
      document.getElementById("nextPageBottom").addEventListener("click", () => changePage(1));
      document.getElementById("itemsPerPage").addEventListener("change", changeItemsPerPage);
    });
});

function applyFilters() {
  let filteredEvents = allEvents;
  const titleValue = document.getElementById("titleFilter").value;
  const dateValue = document.getElementById("dateFilter").value;
  const descriptionValue = document.getElementById("descriptionFilter").value;

  if (titleValue) {
    filteredEvents = filterEvents(filteredEvents, titleValue, titleFilter);
  }
  if (dateValue) {
    filteredEvents = filterEvents(filteredEvents, dateValue, startDateFilter);
  }
  if (descriptionValue) {
    filteredEvents = filterEvents(filteredEvents, descriptionValue, descriptionFilter);
  }

  currentPage = 1;
  displayEvents(filteredEvents);
}

function clearFilters() {
  document.getElementById("titleFilter").value = "";
  document.getElementById("dateFilter").value = "";
  document.getElementById("descriptionFilter").value = "";
  currentPage = 1;
  displayEvents(allEvents);
}

function changePage(delta) {
  currentPage += delta;
  displayEvents(allEvents);
}

function changeItemsPerPage(event) {
  itemsPerPage = event.target.value === 'all' ? 'all' : parseInt(event.target.value, 10);
  currentPage = 1;
  displayEvents(allEvents);
}
